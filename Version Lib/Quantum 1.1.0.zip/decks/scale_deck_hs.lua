
SMODS.Back {
    key = 'scale_deck_hs',
    pos = { x = 8, y = 0 },
    config = {
        extra = {
            hand_size0 = 1,
            hand_size = 2
        },
    },
    loc_txt = {
        name = 'Scale Deck HS',
        text = {
            [1] = 'Start with {C:dark_edition}-2 Hand Size{}',
            [2] = 'But every time you beat',
            [3] = 'a Boss Blind: {C:dark_edition}+1 Hand Size{}'
        },
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    atlas = 'CustomDecks',
    calculate = function(self, card, context)
        if context.end_of_round and context.main_eval and G.GAME.blind.boss then
            return {
                
                G.E_MANAGER:add_event(Event({
                    func = function()
                        
                        
                        G.hand:change_size(1)
                        return true
                    end
                }))
            }
        end
    end,
    apply = function(self, back)
        return {
            
            G.E_MANAGER:add_event(Event({
                func = function()
                    
                    
                    G.hand:change_size(-2)
                    return true
                end
            }))
        }
    end
}