
SMODS.Joker{ --Cerium
    key = "Ce",
    config = {
        extra = {
            xmult0 = 1.5,
            xchips0 = 1.5
        }
    },
    loc_txt = {
        ['name'] = 'Cerium',
        ['text'] = {
            [1] = 'If your deck has more than',
            [2] = '52 Cards: {X:mult,C:white}×1.5{} {C:red}Mult{}',
            [3] = 'If your deck has less than',
            [4] = '52 Cards: {X:chips,C:white}×1.5{} {C:blue}Chips{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 10
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = false,
    atlas = 'CustomJokers',
    pools = { ["quant_quant_jokers"] = true, ["quant_element"] = true },
    
    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if to_big(#G.deck.cards) > to_big(52) then
                return {
                    Xmult = 1.5
                }
            elseif to_big(#G.deck.cards) < to_big(52) then
                return {
                    x_chips = 1.5
                }
            end
        end
    end
}